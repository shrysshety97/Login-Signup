// eslint-disable-next-line no-unused-vars
import React from 'react'
import { useState } from "react"
import axios from 'axios'
import {toast} from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import  './CSS/Registration.css'




const Register = () => {
  const navigate = useNavigate()
  const[data, setData] = useState({
    name: '',
    email: '',
    password: '',
  })


  const registerUser = async (e) => {
    e.preventDefault()
    const {name, email, password} = data
    try {
      const {data} = await axios.post('/register', {
        name, email, password
      })
      if(data.error) {
        toast.error(data.error)
      }else {
        setData({})
        toast.success('Login Successful. Welcome!')
        navigate('/login')
      }
    } catch (error) {
      console.log(error);
    }
  }
  return (
    <div className='container'>

      <form onSubmit={registerUser} className='container-form'>
        <div className='title'><span>Registration</span></div>
        <div className='user-details'>
          <div className='input-box'>
            <label className='details'>Enter Full Name</label>
            <input className='input-box' type='text' placeholder='Enter Name' value={data.name} onChange={(e) => setData({ ...data, name: e.target.value })} /><br />
            <label className='details'>Enter Email-Id</label>
            <input className='input-box' type='email' placeholder='Enter Email' value={data.email} onChange={(e) => setData({ ...data, email: e.target.value })} /><br />
            <label className='details'>Enter Password</label>
            <input className='input-box' type='password' placeholder='Enter Password' value={data.password} onChange={(e) => setData({ ...data, password: e.target.value })} /><br />
          </div>
        </div>
        <div className='input'>
          <button className='button' type='submit'>Submit</button>
        </div>
      </form>
    </div>
  )
}

export default Register