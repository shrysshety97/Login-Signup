// eslint-disable-next-line no-unused-vars
import React from 'react'
import { Link } from 'react-router-dom'
import './Navbar.css'



export default function Navbar() {
  return (
 <div className='float-container'>
       <Link to='/'></Link>
       <h2 className='title'>Hii There!!</h2>
     <div className='input'>
      <button className='button'><Link to='/register' >Register</Link></button> 
      </div>
       <div>     
      <button className='button'><Link to='/login'>Login</Link></button> 
      </div>  
   </div>



  )
}
